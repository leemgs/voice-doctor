# 🔬 이명연구랩 (Tinnitus Research Lab)

> 이명(Tinnitus)과 난청의 원인 규명 및 치료법 연구를 위한 **비영리 독립 연구소** 홈페이지

---

## 📁 파일 구조

```
tinnitus-research-lab/
├── index.html              # 메인 홈페이지
├── README.md
├── css/
│   └── style.css           # 공통 스타일시트
├── js/
│   └── main.js             # 공통 JavaScript
├── images/                 # 모든 SVG 이미지 (31개)
│   ├── hero-bg.svg
│   ├── about-lab.svg
│   ├── cause-*.svg         # 이명 원인 이미지 (6개)
│   ├── case-*.svg          # 치료 사례 이미지 (6개)
│   ├── method-*.svg        # 연구 방법 이미지
│   ├── app-*.svg           # 앱 이미지 (6개)
│   ├── yt-*.svg            # 유튜브 채널 이미지 (4개)
│   └── strip-*.svg         # 스트립 이미지 (4개)
└── pages/
    ├── causes.html         # 이명 원인
    ├── papers.html         # 연구 논문 (국내/국제/체계적 리뷰/신경과학 탭)
    ├── cases.html          # 치료 사례 (6가지 치료법)
    ├── methods.html        # 연구 방법론
    ├── apps.html           # 치료 모바일 앱 + 비교표
    ├── youtube.html        # 유튜브 채널 추천
    ├── resources.html      # 자료실 (기관 링크, DB, 가이드라인)
    └── contact.html        # 문의 & 연구 협력
```

---

## 🌐 GitHub Pages 배포 방법

1. GitHub에서 새 레포지토리 생성
2. 이 폴더 전체를 업로드
3. **Settings → Pages → Branch: main → / (root)** 설정
4. `https://[username].github.io/[repository-name]/` 으로 접속

---

## 📄 페이지 구성

| 페이지 | 파일 | 주요 내용 |
|--------|------|-----------|
| 홈 | `index.html` | 히어로 섹션, 연구소 소개, 빠른 링크 |
| 이명 원인 | `pages/causes.html` | 6가지 원인 카드 (소음, 신경가소성, 혈관성, 이독성, TMJ, 스트레스) |
| 연구 논문 | `pages/papers.html` | 탭 분리: 국제 / 국내 / 체계적 리뷰 / 신경과학 |
| 치료 사례 | `pages/cases.html` | 음향치료, CBT, TRT, rTMS, 생활습관, 보청기 |
| 연구 방법 | `pages/methods.html` | 타임라인 형식 6단계 연구 방법론 |
| 치료 앱 | `pages/apps.html` | 앱 6종 소개 + 기능 비교표 |
| 유튜브 | `pages/youtube.html` | 국내외 채널 6개 + 플레이리스트 |
| 자료실 | `pages/resources.html` | 기관 링크, 학술 DB, 임상 가이드라인 |
| 문의 | `pages/contact.html` | 문의 폼, FAQ, 협력 유형 |

---

## 🎨 디자인 특징

- **색상**: Deep Navy + Teal(청록) + Gold 3색 팔레트
- **폰트**: Playfair Display (제목) + Noto Sans KR (본문) + JetBrains Mono (코드)
- **이미지**: 모든 이미지 SVG 형식 (완전 자체 포함, 외부 의존 없음)
- **반응형**: 모바일, 태블릿, 데스크탑 완전 지원
- **애니메이션**: 스크롤 기반 Reveal 애니메이션

---

## ⚠️ 면책 조항

본 웹사이트는 **비영리 독립 연구 목적**으로 운영되며, 의료 행위를 제공하지 않습니다.
이명 증상이 있으신 경우 반드시 이비인후과 전문의와 상담하시기 바랍니다.

---

© 2025 이명연구랩 (Tinnitus Research Lab) · Non-Profit Independent Research
