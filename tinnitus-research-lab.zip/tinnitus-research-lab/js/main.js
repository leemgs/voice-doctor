// ── NAV TOGGLE ──
function toggleNav() {
  document.getElementById('navLinks').classList.toggle('open');
}

// ── ACTIVE NAV LINK ──
(function() {
  const path = window.location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.nav-links a').forEach(a => {
    const href = a.getAttribute('href').split('/').pop();
    if (href === path) a.classList.add('active');
  });
})();

// ── SCROLL REVEAL ──
const observer = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting) {
      const siblings = Array.from(entry.target.parentElement?.children || []);
      const idx = siblings.indexOf(entry.target) % 5;
      setTimeout(() => entry.target.classList.add('visible'), idx * 70);
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.08 });

document.querySelectorAll('.reveal').forEach(el => observer.observe(el));

// ── TAB SWITCHING ──
function switchTab(e, tabId) {
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
  e.currentTarget.classList.add('active');
  const panel = document.getElementById(tabId);
  if (panel) {
    panel.classList.add('active');
    panel.querySelectorAll('.reveal').forEach(el => observer.observe(el));
  }
}

// ── SCROLL NAV HIGHLIGHT (single-page sections) ──
const sections = document.querySelectorAll('section[id]');
if (sections.length > 0) {
  window.addEventListener('scroll', () => {
    let current = '';
    sections.forEach(sec => {
      if (window.scrollY >= sec.offsetTop - 80) current = sec.id;
    });
    document.querySelectorAll('.nav-links a[href^="#"]').forEach(a => {
      a.style.color = a.getAttribute('href') === '#' + current ? 'var(--teal)' : '';
    });
  });
}

// ── FORM SUBMIT (demo) ──
document.addEventListener('DOMContentLoaded', () => {
  const btn = document.querySelector('.form-submit');
  if (btn) btn.addEventListener('click', () => alert('메시지가 전송되었습니다. 감사합니다!'));
});
